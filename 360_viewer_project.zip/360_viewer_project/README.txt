# 360° Viewer with Hotspots

Este proyecto es un visor básico de imágenes 360° con hotspots interactivos.

## ¿Cómo usarlo?
1. Abre el archivo `index.html` en un navegador web.
2. Navega entre imágenes con las flechas izquierda y derecha del teclado.
3. Haz clic en los puntos (hotspots) para abrir los enlaces.

## Subirlo a Internet
1. Sube la carpeta completa a un servicio como:
   - [GitHub Pages](https://pages.github.com/)
   - [Netlify](https://www.netlify.com/)
   - [Vercel](https://vercel.com/).
2. Comparte la URL generada.
